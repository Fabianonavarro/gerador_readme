# Gerador de README.md

Um gerador de README.md para projetos Python.

## Instalação

Para instalar o pacote, use o seguinte comando:

```bash
pip install gerador-readme
